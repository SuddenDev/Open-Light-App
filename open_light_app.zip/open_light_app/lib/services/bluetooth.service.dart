class BluetoothService {
  
  //Scan For Devices

}